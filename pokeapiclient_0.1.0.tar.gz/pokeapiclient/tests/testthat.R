library(testthat)
library(pokeapiclient)

test_check("pokeapiclient")
